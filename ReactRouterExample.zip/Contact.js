//Router example https://www.javatpoint.com/react-router
import React from 'react';
class Contact extends React.Component{
  render(){
     return(
       <h1> CONTACT </h1>
     );
  }
}
export default Contact;
