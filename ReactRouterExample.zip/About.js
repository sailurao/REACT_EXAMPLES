//Router example https://www.javatpoint.com/react-router
import React from 'react';
class About extends React.Component{
  render(){
     return(
       <h1> About </h1>
     );
  }
}
export default About;
