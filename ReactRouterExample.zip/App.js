//Router example https://www.javatpoint.com/react-router
import React from 'react';
class App extends React.Component{
  render(){
     return(
       <h1> HOME </h1>
     );
  }
}
export default App;
